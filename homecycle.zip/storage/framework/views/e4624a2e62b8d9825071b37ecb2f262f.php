<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'categories' => [],
    'query' => null,
    'categorySlug' => null,
    'action' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'categories' => [],
    'query' => null,
    'categorySlug' => null,
    'action' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $action = $action ?: route('web.search');
?>

<form action="<?php echo e($action); ?>" method="GET" class="w-full">
    <div class="flex w-full items-stretch gap-2">
        <?php if(!empty($categories)): ?>
            <div class="hidden sm:block">
                <select name="category_slug" class="h-full w-44 rounded-xl border border-slate-300 bg-white px-3 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900/10 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100">
                    <option value=""><?php echo e(__('ui.all_categories')); ?></option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat['slug']); ?>" <?php if(($categorySlug ?? request('category_slug')) === $cat['slug']): echo 'selected'; endif; ?>><?php echo e($cat['name']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        <?php endif; ?>

        <input
            name="q"
            value="<?php echo e($query ?? request('q')); ?>"
            placeholder="<?php echo e(__('ui.search_placeholder')); ?>"
            class="h-11 w-full rounded-xl border border-slate-300 bg-white px-4 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900/10 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
        />

        <button class="h-11 shrink-0 rounded-xl bg-slate-900 px-4 text-sm font-semibold text-white hover:bg-slate-800 dark:bg-slate-100 dark:text-slate-900 dark:hover:bg-white"><?php echo e(__('ui.search')); ?></button>
    </div>
</form>
<?php /**PATH C:\xampp\htdocs\projects\smigul\homeCycle\resources\views/components/search-bar.blade.php ENDPATH**/ ?>