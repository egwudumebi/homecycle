<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(($category['name'] ?? 'Category').' - Marketplace'); ?></title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/homecycle_favicon.png')); ?>">
    <style>
        :root{--bg:#f8fafc;--card:#fff;--text:#0f172a;--muted:#64748b;--border:#e2e8f0;--shadow:0 10px 30px rgba(15,23,42,.08);--shadow-sm:0 1px 2px rgba(15,23,42,.06);--indigo:#4f46e5}
        html.dark{--bg:#020617;--card:#0b1220;--text:#e2e8f0;--muted:#94a3b8;--border:rgba(148,163,184,.18);--shadow:0 10px 30px rgba(0,0,0,.35);--shadow-sm:0 1px 2px rgba(0,0,0,.35)}
        *{box-sizing:border-box}
        body{margin:0;font-family:ui-sans-serif,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,"Apple Color Emoji","Segoe UI Emoji";background:var(--bg);color:var(--text)}
        a{color:inherit;text-decoration:none}
        .container{max-width:1120px;margin:0 auto;padding:0 16px}
        .header{position:sticky;top:0;z-index:50;backdrop-filter:blur(10px);background:rgba(255,255,255,.9);border-bottom:1px solid var(--border)}
        html.dark .header{background:rgba(2,6,23,.85)}
        .header-row{display:flex;align-items:center;gap:12px;padding:14px 0}
        .logo img{height:64px;width:auto;display:block}
        .grow{flex:1}
        .btn-icon{height:40px;width:40px;border-radius:12px;border:1px solid var(--border);background:var(--card);display:inline-flex;align-items:center;justify-content:center;cursor:pointer;box-shadow:var(--shadow-sm)}
        .search{display:flex;gap:10px;align-items:center;background:var(--card);border:1px solid var(--border);border-radius:14px;padding:10px 12px;box-shadow:var(--shadow-sm)}
        .search input{width:100%;border:none;outline:none;font-size:14px;color:var(--text);background:transparent}
        .search button{border:none;background:var(--text);color:#fff;font-weight:800;font-size:13px;padding:10px 14px;border-radius:12px;cursor:pointer}
        html.dark .search button{background:#e2e8f0;color:#0f172a}
        .main{padding:22px 0 44px}
        .crumb{display:flex;gap:8px;align-items:center;font-size:11px;font-weight:900;letter-spacing:.14em;text-transform:uppercase;color:var(--muted)}
        .crumb a:hover{color:var(--indigo)}
        .head{display:flex;align-items:flex-end;justify-content:space-between;gap:14px;margin-top:14px}
        .h1{margin:0;font-size:28px;letter-spacing:-.02em}
        .p{margin:8px 0 0;color:var(--muted);font-size:13px}
        .btn{display:inline-flex;align-items:center;justify-content:center;gap:10px;border-radius:14px;border:1px solid var(--border);background:var(--card);padding:10px 14px;font-weight:900;box-shadow:var(--shadow-sm)}
        .btn:hover{border-color:rgba(79,70,229,.25);box-shadow:var(--shadow)}
        .layout{display:grid;grid-template-columns:1fr;gap:16px;margin-top:18px}
        @media(min-width:1024px){.layout{grid-template-columns:320px 1fr}}
        .panel{border:1px solid var(--border);background:var(--card);border-radius:18px;box-shadow:var(--shadow-sm);overflow:hidden}
        .panel-h{padding:14px 16px;border-bottom:1px solid var(--border);font-weight:900;letter-spacing:.14em;text-transform:uppercase;font-size:11px;color:var(--muted)}
        .panel-b{padding:12px}
        .sub a{display:flex;justify-content:space-between;gap:10px;align-items:center;border-radius:12px;padding:10px 12px;font-weight:800;color:var(--muted)}
        .sub a:hover{background:rgba(79,70,229,.08);color:var(--indigo)}
        .tag{border-radius:10px;background:rgba(148,163,184,.12);padding:3px 8px;font-size:10px;font-weight:900;color:var(--muted)}
        .grid{display:grid;grid-template-columns:repeat(1,minmax(0,1fr));gap:12px}
        @media(min-width:640px){.grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
        @media(min-width:1280px){.grid{grid-template-columns:repeat(3,minmax(0,1fr))}}
        .card{display:block;overflow:hidden;border-radius:18px;border:1px solid var(--border);background:var(--card);box-shadow:var(--shadow-sm);transition:transform .15s ease, box-shadow .15s ease}
        .card:hover{transform:translateY(-2px);box-shadow:var(--shadow)}
        .media{aspect-ratio:4/3;background:rgba(148,163,184,.25)}
        .media img{width:100%;height:100%;object-fit:cover;display:block}
        .body{padding:14px}
        .t{font-weight:900;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
        .meta{margin-top:10px;display:flex;justify-content:space-between;gap:10px;align-items:baseline}
        .price{font-weight:900}
        .loc{font-size:12px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
        .empty{border:2px dashed var(--border);border-radius:22px;padding:46px 16px;text-align:center;color:var(--muted);font-weight:900}
        .pager{margin-top:18px}
        .pager a{border:1px solid var(--border);background:var(--card);padding:10px 12px;border-radius:12px;box-shadow:var(--shadow-sm);font-weight:900;color:var(--muted)}
        .pager a:hover{color:var(--indigo)}
    </style>
    <script>
        (()=>{const stored=localStorage.getItem('theme');const theme=stored==='light'||stored==='dark'?stored:(window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light');if(theme==='dark')document.documentElement.classList.add('dark');})();
        window.addEventListener('DOMContentLoaded',()=>{document.querySelectorAll('[data-theme-toggle]').forEach(btn=>{btn.addEventListener('click',()=>{const root=document.documentElement;const next=root.classList.contains('dark')?'light':'dark';if(next==='dark')root.classList.add('dark');else root.classList.remove('dark');localStorage.setItem('theme',next);});});});
    </script>
</head>
<body>
<header class="header">
    <div class="container">
        <div class="header-row">
            <a class="logo" href="<?php echo e(route('web.home')); ?>"><img src="<?php echo e(asset('images/homecycle_dark_bg.png')); ?>" alt="HomeCycle" /></a>
            <div class="grow">
                <form action="<?php echo e(route('web.search')); ?>" method="GET">
                    <div class="search">
                        <input name="q" value="<?php echo e(request('q')); ?>" placeholder="<?php echo e(__('ui.search_placeholder')); ?>" />
                        <button type="submit"><?php echo e(__('ui.search')); ?></button>
                    </div>
                </form>
            </div>
            <button type="button" class="btn-icon" data-theme-toggle aria-label="Toggle theme">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364-.707.707M6.343 17.657l-.707.707m12.728 0-.707-.707M6.343 6.343l-.707-.707M12 8a4 4 0 100 8 4 4 0 000-8z"/></svg>
            </button>
        </div>
    </div>
</header>

<main class="main">
    <div class="container">
        <div class="crumb">
            <a href="<?php echo e(route('web.home')); ?>">Home</a>
            <span style="opacity:.5;">/</span>
            <span style="color:var(--text);"><?php echo e($category['name'] ?? 'Category'); ?></span>
        </div>

        <div class="head">
            <div>
                <h1 class="h1"><?php echo e($category['name'] ?? 'Category'); ?></h1>
                <p class="p">Discover <?php echo e(count($listings ?? [])); ?> active listings in this category.</p>
            </div>
            <a class="btn" href="<?php echo e(route('web.search', ['category_slug' => $category['slug'] ?? null])); ?>">
                <span>Advanced Filters</span>
                <span style="color:var(--muted);">→</span>
            </a>
        </div>

        <div class="layout">
            <aside>
                <div class="panel">
                    <div class="panel-h">Sub-categories</div>
                    <div class="panel-b sub">
                        <?php $__currentLoopData = ($category['sub_categories'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('web.search', ['sub_category_id' => $sub['id']])); ?>">
                                <span><?php echo e($sub['name']); ?></span>
                                <span class="tag">→</span>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </aside>

            <section>
                <div class="grid">
                    <?php $__empty_1 = true; $__currentLoopData = ($listings ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $img = $item['image']['url'] ?? null;
                            $city = $item['location']['city']['name'] ?? null;
                            $state = $item['location']['state']['name'] ?? null;
                            $title = $item['title'] ?? '';
                            $price = (float) ($item['price'] ?? 0);
                        ?>
                        <a class="card" href="<?php echo e(route('web.listing.show', ['slug' => $item['slug']])); ?>">
                            <div class="media">
                                <?php if($img): ?>
                                    <img src="<?php echo e($img); ?>" alt="" loading="lazy" />
                                <?php else: ?>
                                    <div style="display:flex;align-items:center;justify-content:center;height:100%;color:var(--muted);font-size:13px;">No image</div>
                                <?php endif; ?>
                            </div>
                            <div class="body">
                                <div class="t"><?php echo e($title); ?></div>
                                <div class="meta">
                                    <div class="price">₦<?php echo e(number_format($price, 2)); ?></div>
                                    <div class="loc"><?php echo e($city); ?><?php echo e($city ? ',' : ''); ?> <?php echo e($state); ?></div>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="empty" style="grid-column:1/-1;">No listings yet</div>
                    <?php endif; ?>
                </div>

                <?php
                    $page = (int) request('page', 1);
                    $hasNext = is_array($meta ?? null) && isset($meta['current_page'], $meta['last_page']) && (int) $meta['current_page'] < (int) $meta['last_page'];
                    $hasPrev = $page > 1;
                ?>

                <div class="pager" style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;">
                    <?php if($hasPrev): ?>
                        <a href="<?php echo e(request()->fullUrlWithQuery(['page' => $page - 1])); ?>">← Prev</a>
                    <?php endif; ?>
                    <?php if($hasNext): ?>
                        <a href="<?php echo e(request()->fullUrlWithQuery(['page' => $page + 1])); ?>">Next →</a>
                    <?php endif; ?>
                </div>
            </section>
        </div>
    </div>
</main>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\projects\smigul\homeCycle\resources\views/web/category_single.blade.php ENDPATH**/ ?>