<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['item']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['item']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $img = $item['image']['url'] ?? null;
    $title = $item['title'] ?? '';
    $price = (float) ($item['price'] ?? 0);
    $storeName = (string) config('app.store.name', 'HomeCycle');
?>

<a href="<?php echo e(route('web.listing.show', ['slug' => $item['slug']])); ?>" class="group block overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm transition hover:-translate-y-0.5 hover:shadow-md active:scale-[0.99] dark:border-slate-800 dark:bg-slate-900">
    <div class="relative aspect-[4/3] bg-slate-100 dark:bg-slate-800">
        <?php if($img): ?>
            <img src="<?php echo e($img); ?>" alt="" class="h-full w-full object-cover" loading="lazy" />
        <?php else: ?>
            <div class="flex h-full w-full items-center justify-center text-sm text-slate-500 dark:text-slate-300">No image</div>
        <?php endif; ?>
    </div>

    <div class="p-4 sm:p-5">
        <div class="text-xs sm:text-sm font-semibold text-slate-900 truncate dark:text-slate-100"><?php echo e($title); ?></div>

        <div class="mt-3 flex items-center justify-between gap-3">
            <div class="text-base font-extrabold tracking-tight text-slate-900 dark:text-slate-100">₦<?php echo e(number_format($price, 2)); ?></div>
            <div class="text-xs font-medium text-slate-600 truncate dark:text-slate-300">Sold by <?php echo e($storeName); ?></div>
        </div>

        <div class="mt-4">
            <button type="button" class="w-full inline-flex items-center justify-center gap-2 rounded-2xl bg-slate-900 px-4 py-3 text-xs font-black text-white transition hover:bg-slate-800 active:scale-[0.99] dark:bg-white dark:text-slate-900" onclick="event.preventDefault(); event.stopPropagation(); if (!window.hcCart || (window.hcCart.isPending && window.hcCart.isPending('add:<?php echo e((int) ($item['id'] ?? 0)); ?>'))) return; window.hcCart.add(<?php echo e((int) ($item['id'] ?? 0)); ?>, 1).catch(() => {})">
                <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2 9m12-9l2 9M9 22a1 1 0 100-2 1 1 0 000 2zm10 0a1 1 0 100-2 1 1 0 000 2z"/>
                </svg>
                Add to cart
            </button>
        </div>
    </div>
</a>
<?php /**PATH C:\xampp\htdocs\projects\smigul\homeCycle\resources\views/components/listing-card.blade.php ENDPATH**/ ?>