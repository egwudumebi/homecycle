<?php

return [
    'saved' => 'Saved',
    'search' => 'Search',
    'all_categories' => 'All categories',
    'search_placeholder' => 'Search items, brands and categories',
    'footer_tagline' => 'Browse store inventory, save favorites, and contact our store directly.',
    'marketplace' => 'Marketplace',
];
