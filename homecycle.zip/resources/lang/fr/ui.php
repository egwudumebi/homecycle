<?php

return [
    'saved' => 'Enregistrés',
    'search' => 'Rechercher',
    'all_categories' => 'Toutes les catégories',
    'search_placeholder' => 'Rechercher des articles, marques et catégories',
    'footer_tagline' => 'Parcourez l\'inventaire, enregistrez vos favoris et contactez directement notre boutique.',
    'marketplace' => 'Marketplace',
];
